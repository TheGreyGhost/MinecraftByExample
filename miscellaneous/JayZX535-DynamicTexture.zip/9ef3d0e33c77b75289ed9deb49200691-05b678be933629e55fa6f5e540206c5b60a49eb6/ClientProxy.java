package com.wildcraft.wildcraft;

import com.wildcraft.wildcraft.util.renderer.WCAdvancedEntityTextureHandler;

public class ClientProxy implements IProxy{
	
	private static WCAdvancedEntityTextureHandler wcadvancedentitytexturehandler = new WCAdvancedEntityTextureHandler();
	
	public static WCAdvancedEntityTextureHandler getAdvancedEntityTextureHandler()
	{
		return wcadvancedentitytexturehandler;
	}

}