package com.wildcraft.wildcraft.render.wolf;

import javax.annotation.Nullable;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import com.mojang.blaze3d.platform.GlStateManager;
import com.wildcraft.wildcraft.ClientProxy;
import com.wildcraft.wildcraft.entity.canid.WCWolfEntity;
import com.wildcraft.wildcraft.models.entity.WCWolfModel;
import com.wildcraft.wildcraft.util.renderer.WCAdvancedEntityTextureHandler;

@OnlyIn(Dist.CLIENT)
public class WCWolfRenderer extends MobRenderer<WCWolfEntity, WCWolfModel<WCWolfEntity>> {

   private WCAdvancedEntityTextureHandler texhandler;
	
   public WCWolfRenderer(EntityRendererManager renderManagerIn) {
      super(renderManagerIn, new WCWolfModel<>(0.0F), 0.5F);
      this.texhandler = ClientProxy.getAdvancedEntityTextureHandler()
   }

   public void doRender(WCWolfEntity entity, double x, double y, double z, float entityYaw, float partialTicks) {
       super.doRender(entity, x, y, z, entityYaw, partialTicks);
   }

   @Nullable
   @Override
   protected ResourceLocation getEntityTexture(WCWolfEntity entity) {
	   return this.texhandler.getTextureLocation(entity);
   }
}