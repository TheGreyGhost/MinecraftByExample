package com.wildcraft.wildcraft.util.renderer;

import com.google.common.collect.Maps;
import com.wildcraft.wildcraft.entity.WCAnimalEntity;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.annotation.Nullable;
import javax.imageio.ImageIO;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class WCAdvancedEntityTextureHandler implements AutoCloseable {

   private final Map<String, WCAdvancedEntityTextureHandler.Instance> loadedEntities = Maps.newHashMap();

   public WCAdvancedEntityTextureHandler() {
   }
   
   /**
    * Updates the texture data for this entity's instance of the texture handler (an instance is created by getEntityInstance if none exists)
    */
   public void updateEntityTexture(WCAnimalEntity entity) {
      this.getEntityInstance(entity).updateEntityTexture();
   }
   
   /**
    * Returns the texture location for this entity's instance of the texture handler (an instance is created by getEntityInstance if none exists)
    */
   
   public ResourceLocation getTextureLocation(WCAnimalEntity entity){
	   return this.getEntityInstance(entity).getResourceLocation();
   }
   
   /**
    * Checks to see if an instance of the texture handler exists for this entity
    */
   
   @Nullable
   public WCAdvancedEntityTextureHandler.Instance getInstanceIfExists(WCAnimalEntity entity) {
      return this.loadedEntities.get(entity.getUniqueID().toString());
   }
   
   /**
    * Returns an instance of the texture handler corresponding to the inputted entity
    */
   private WCAdvancedEntityTextureHandler.Instance getEntityInstance(WCAnimalEntity entity) {
	   WCAdvancedEntityTextureHandler.Instance handler$instance = this.loadedEntities.get(entity.getUniqueID().toString());
      if (handler$instance == null) {
    	  handler$instance = new WCAdvancedEntityTextureHandler.Instance(entity);
         this.loadedEntities.put(entity.getUniqueID().toString(), handler$instance);
      }
      return handler$instance;
   }
   
   /**
    * Clears the currently loaded entities and removes their corresponding textures
    */
   public void clearLoadedEntities() {
      for(WCAdvancedEntityTextureHandler.Instance texturehandler$instance : this.loadedEntities.values()) {
    	  texturehandler$instance.close();
      }
      this.loadedEntities.clear();
   }
   
   /**
    * Closes the entity texture handler
    */
   public void close() {
	      this.clearLoadedEntities();
   }
   
   /**
    * Instances of this texture handler are based off the submitted entity
    */
   @OnlyIn(Dist.CLIENT)
   class Instance implements AutoCloseable {
	   private final WCAnimalEntity entity;
	   private final DynamicTexture entityTexture;
	   private final ResourceLocation location;

	   private Instance(WCAnimalEntity entity) {
		   this.entity = entity;
		   this.entityTexture = new DynamicTexture(entity.getTexHeight(), entity.getTexWidth(), true);
		   this.location = Minecraft.getInstance().getTextureManager().getDynamicTextureLocation("wildcraft/entity/" + entity.getSpeciesIdentifier(), this.entityTexture);
		   this.updateEntityTexture();
	   }
	   
	   public DynamicTexture getEntityTexture(){
		   return this.entityTexture;
	   }
	   
	   /**
	    * Updates an entity texture
	    */
	   private void updateEntityTexture() {
		   
		 //Sets the base layer for the entity texture
	  	 BufferedImage layer = this.getColoredLayer(0);
	  	 BufferedImage output = layer;
	  	 
	  	 //Number of texture layers is defined in an entity's class (base layer is #0).  If there are additional texture layers to overlay onto the base, this adds them progressively.
	  	 if (this.entity.getAdvancedTexLayers() > 1)
	  	 {
	  		 for (int i = 1; i < this.entity.getAdvancedTexLayers(); i++)
	  		 {
	  			 layer = this.getColoredLayer(i);
	  			 output = this.combineImages(output, layer);
	  		 }
	  			 
	  	 }
	  	 //Buffered image converted to NativeImage to be added to the dynamic texture
	  	 NativeImage texture = this.convertFromBufferedImage(output);
	  	 try {
			this.entityTexture.setTextureData(texture);
			} catch (Exception e) {
			e.printStackTrace();
		 }
	     this.entityTexture.updateDynamicTexture();
	   }
	   
	   /**
	    * Loads a texture file and then applies color to it.  Texture and color determined within each species' class.
	    */
	   private BufferedImage getColoredLayer(int id)
	   {
		   BufferedImage img = this.loadTextureFile(id);
		   img = this.applyColor(img, this.getTextureColor(id), false);
		   return img;
	   }
	   
	   /**
	    * Loads a texture from a specified file (path defined based off layer id in species class).
	    */
	   private BufferedImage loadTextureFile(int id)
	   {
		 	BufferedImage img = new BufferedImage(this.entity.getTexHeight(), this.entity.getTexWidth(), BufferedImage.TYPE_INT_ARGB);
		 	if (!this.entity.getTextureLocation(id).equals(""))
		 	{
		 		ResourceLocation filelocation = new ResourceLocation(this.entity.getTextureLocation(id) + ".png");
				InputStream inputstream = null;
				try {
					inputstream = Minecraft.getInstance().getResourceManager().getResource(filelocation).getInputStream();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				if (inputstream != null)
				{
					try {
						img = ImageIO.read(inputstream);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
		 	}

			return img;
	   }
	   
	   /**
	    * Returns a color for the specified layer id based off species class
	    */
	   private Color getTextureColor(int id)
	   {
		   return new Color(this.entity.getTextureColor(id)[0], this.entity.getTextureColor(id)[1], this.entity.getTextureColor(id)[2]);
	   }
	   
	   /**
	    * Applies color (via multiplication) to image and returns it.
	    */
	   private BufferedImage applyColor(BufferedImage img, Color tint)
	   {
		   BufferedImage tintedImg = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
		   Graphics2D graphics = tintedImg.createGraphics();
		   graphics.drawImage(img, 0, 0, null);
		   graphics.dispose();
		   
		   float redBase = (float) tint.getRed() * (1/255F);
		   float greenBase = (float) tint.getGreen() * (1/255F);
		   float blueBase = (float) tint.getBlue() * (1/255F);
		   
		   for (int i = 0; i < tintedImg.getWidth(); i++)
		   {
			   for (int j = 0; j < tintedImg.getHeight(); j++)
		       {
				   float alpha = (float) tintedImg.getColorModel().getAlpha(tintedImg.getRaster().getDataElements(i, j, null)) * (1/255F);
			       float redTint = (float) tintedImg.getColorModel().getRed(tintedImg.getRaster().getDataElements(i, j, null)) * (1/255F);
			       float greenTint = (float) tintedImg.getColorModel().getGreen(tintedImg.getRaster().getDataElements(i, j, null)) * (1/255F);
			       float blueTint = (float) tintedImg.getColorModel().getBlue(tintedImg.getRaster().getDataElements(i, j, null)) * (1/255F);
			       
			       float redOut = redBase * redTint;
			       float greenOut = greenBase * greenTint;
			       float blueOut = blueBase * blueTint;
			       
			       Color colorOut = new Color (redOut, greenOut, blueOut, alpha);
			       //NOTE:  Problem encountered with R/B being inverted.  Seemed to be java issue.  getARGB provides option to invert R/B (ABGR) to correct this.
			       tintedImg.setRGB(i, j, this.getARGB(true, colorOut));
		       }
		   }
		   
		   return tintedImg;
	   }
	   
	   /**
	    * Returns an ARGB int to set pixel RGB.  Can be inverted to ABGR (to fix java issue)
	    */
	   private int getARGB(boolean invert, Color color)
	   {
		   int colOut = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();
		   if (invert) colOut = (color.getAlpha() << 24) | (color.getBlue() << 16) | (color.getGreen() << 8) | color.getRed();
		   return colOut;
	   }
	   
	   /**
	    * Combines the two inputted images, with the overlay on top
	    */
	   private BufferedImage combineImages(BufferedImage base, BufferedImage overlay)
	   {
	 	  BufferedImage output = base;
	 	  
	 	  Graphics2D g = output.createGraphics();
		  g.drawImage(output, 0, 0, null);
		  g.setComposite(AlphaComposite.SrcAtop);
		  g.drawImage(overlay, 0, 0, null);
		  g.dispose();
	 	  return output;
	   }
	   
	   
	   /**
	    * Converts a BufferedImage into a NativeImage to use for dynamic texture
	    */
	   private NativeImage convertFromBufferedImage(BufferedImage bufferedimage)
	   {
	 	  NativeImage nativeimage = new NativeImage(bufferedimage.getHeight(), bufferedimage.getWidth(), true);
	 	  for (int i = 0; i < bufferedimage.getWidth(); i++) {
	 			for (int j = 0; j < bufferedimage.getHeight(); j++) {
	 				nativeimage.setPixelRGBA(i, j, bufferedimage.getRGB(i, j));
	 			}
	 		}
	 	  return nativeimage;
	   }
	   
	   public ResourceLocation getResourceLocation()
	   {
		   return this.location;
	   }
	   
	   public void close() {
	       this.entityTexture.close();
	   }
   }

}